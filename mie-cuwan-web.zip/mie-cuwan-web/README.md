# Website Mie Cuwan (Next.js)

## Jalankan
1. Instal Node.js 20.9+.
2. Buka terminal di folder ini.
3. Jalankan `npm install`.
4. Jalankan `npm run dev`.
5. Buka http://localhost:3000.

## Sebelum digunakan untuk bisnis
- Ubah menu, harga, nomor WhatsApp, alamat, jam buka dan tautan Google Maps di `lib/data.ts`.
- Data awal **hanya contoh**, bukan informasi resmi. Kedua tautan Maps dalam data adalah placeholder dan sengaja tidak ditampilkan sebagai tombol aktif.
- Isi nomor WhatsApp dengan format 62... tanpa +, spasi, atau tanda hubung. Setelah diisi, tombol Pesan akan membuka WhatsApp dengan ringkasan keranjang.
- Ganti ilustrasi emoji dengan foto asli setelah mendapat foto produk.
- Jalankan `npm run build` sebelum deploy ke Vercel.

Stack: Next.js App Router, TypeScript, Tailwind CSS 3, Framer Motion, Lucide React.
