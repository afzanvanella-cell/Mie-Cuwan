"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu as MenuIcon, Moon, ShoppingBag, Sun, Utensils, X } from "lucide-react";
import { useState } from "react";
import { useSite } from "./Providers";
const links = [{ href: "/", label: "Beranda" }, { href: "/menu", label: "Menu" }, { href: "/tentang", label: "Tentang Kami" }, { href: "/lokasi", label: "Lokasi" }];
export default function Navbar() {
 const { dark, toggle, cart } = useSite(); const [open, setOpen] = useState(false); const path = usePathname(); const count = cart.reduce((n,x) => n+x.qty,0);
 return <header className="sticky top-0 z-50 bg-red-700 text-white shadow-lg"><nav className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4">
  <Link href="/" className="flex items-center gap-2 text-xl font-black tracking-wide"><Utensils className="text-yellow-300"/> MIE CUWAN</Link>
  <div className="hidden items-center gap-6 md:flex">{links.map(l => <Link key={l.href} href={l.href} className={`font-bold hover:text-yellow-300 ${path===l.href?"text-yellow-300":""}`}>{l.label}</Link>)}</div>
  <div className="flex items-center gap-2"><button onClick={toggle} aria-label="Ganti tema" className="rounded-full p-2 hover:bg-red-800">{dark?<Sun/>:<Moon/>}</button><Link href="/menu#keranjang" className="flex items-center gap-2 rounded-full bg-yellow-400 px-3 py-2 font-bold text-red-950 hover:bg-yellow-300"><ShoppingBag size={19}/> <span className="hidden sm:inline">Keranjang</span> ({count})</Link><button className="rounded-lg p-2 md:hidden" onClick={()=>setOpen(v=>!v)} aria-label="Buka navigasi" aria-expanded={open}>{open?<X/>:<MenuIcon/>}</button></div>
 </nav>{open&&<div className="border-t border-red-600 px-5 pb-4 md:hidden">{links.map(l=><Link onClick={()=>setOpen(false)} className="block py-3 font-semibold" key={l.href} href={l.href}>{l.label}</Link>)}</div>}</header>;
}
