"use client";
import { createContext, useContext, useEffect, useState } from "react";
import type { ReactNode } from "react";
import type { MenuItem } from "@/lib/data";
type CartItem = { item: MenuItem; qty: number };
type Context = { dark: boolean; toggle: () => void; cart: CartItem[]; add: (item: MenuItem) => void; change: (id: string, delta: number) => void; clear: () => void };
const SiteContext = createContext<Context | null>(null);
export function Providers({ children }: { children: ReactNode }) {
  const [dark, setDark] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  useEffect(() => { const saved = localStorage.getItem("mie-cuwan-theme"); setDark(saved ? saved === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches); }, []);
  useEffect(() => { document.documentElement.classList.toggle("dark", dark); localStorage.setItem("mie-cuwan-theme", dark ? "dark" : "light"); }, [dark]);
  const add = (item: MenuItem) => setCart(prev => { const found = prev.find(x => x.item.id === item.id); return found ? prev.map(x => x.item.id === item.id ? { ...x, qty: x.qty + 1 } : x) : [...prev, { item, qty: 1 }]; });
  const change = (id: string, delta: number) => setCart(prev => prev.map(x => x.item.id === id ? { ...x, qty: x.qty + delta } : x).filter(x => x.qty > 0));
  return <SiteContext.Provider value={{ dark, toggle: () => setDark(v => !v), cart, add, change, clear: () => setCart([]) }}>{children}</SiteContext.Provider>;
}
export function useSite() { const value = useContext(SiteContext); if (!value) throw new Error("useSite requires Providers"); return value; }
