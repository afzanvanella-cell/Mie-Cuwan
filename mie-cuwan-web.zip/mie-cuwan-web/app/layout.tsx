import type { Metadata } from "next";
import "./globals.css";
import { Providers } from "@/components/Providers";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
export const metadata: Metadata = { title: "Mie Cuwan | Menu & Lokasi", description: "Jelajahi menu dan lokasi Mie Cuwan. Informasi pemesanan menunggu konfirmasi resmi." };
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="id" suppressHydrationWarning><body className="bg-yellow-50 font-sans text-gray-900 transition-colors dark:bg-gray-900 dark:text-gray-100"><Providers><Navbar/><main>{children}</main><Footer/></Providers></body></html>}
