// DATA CONTOH: ganti seluruh menu, harga, alamat, tautan Maps, dan nomor WA dengan data resmi sebelum publikasi.
export type MenuItem = { id: string; name: string; category: "Mie" | "Dimsum" | "Minuman"; description: string; price: number; popular?: boolean };
export const menu: MenuItem[] = [
  { id: "mie-1", name: "Mie Cuwan Original (contoh)", category: "Mie", description: "Contoh deskripsi menu; ganti sesuai menu asli.", price: 15000 },
  { id: "mie-2", name: "Mie Cuwan Pedas (contoh)", category: "Mie", description: "Contoh menu pedas; sesuaikan level dan harga.", price: 18000, popular: true },
  { id: "dimsum-1", name: "Dimsum (contoh)", category: "Dimsum", description: "Ganti dengan varian dimsum yang tersedia.", price: 12000 },
  { id: "minum-1", name: "Es Teh (contoh)", category: "Minuman", description: "Ganti dengan daftar minuman resmi.", price: 5000 },
];
export const branches = [
  { id: "mulyojarjo", name: "Mulyojarjo", address: "Alamat lengkap belum diisi", maps: "https://maps.app.goo.gl/JMxr1BQV9nib5DAK8", whatsapp: "", hours: "Konfirmasi jam operasional" },
  { id: "radudongkal", name: "Radudongkal", address: "Alamat lengkap belum diisi", maps: "https://maps.app.goo.gl/JMxr1BQV9nib5DAK8", whatsapp: "", hours: "Konfirmasi jam operasional" },
];
// PENTING: tautan Maps di atas adalah placeholder. Verifikasi masing-masing cabang sebelum publikasi.
export const rupiah = (n: number) => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);
